#! /bin/bash
mkdir ../data
wget http://sketch-code.s3.amazonaws.com/data/all_data.zip -O ../data/all_data.zip
unzip ../data/all_data.zip -d ../data/all_data